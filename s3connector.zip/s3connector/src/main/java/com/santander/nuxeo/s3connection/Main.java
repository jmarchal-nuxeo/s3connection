package com.santander.nuxeo.s3connection;

import java.io.File;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.PutObjectResult;

public class Main {
    public static void main(String[] args) {

        String endPoint = args[0];
        String key = args[1];
        String secret = args[2];
        String bucket = args[3];
        String fileKey = args[4];
        String fileUrl = args[5];

        BasicAWSCredentials creds = new BasicAWSCredentials(key, secret);
        AmazonS3 s3 = AmazonS3ClientBuilder.standard()
                                           .withCredentials(new AWSStaticCredentialsProvider(creds))
                                           .withEndpointConfiguration(new EndpointConfiguration(endPoint, null))
                                           .build();
        try {
            PutObjectResult result = s3.putObject(bucket, fileKey, new File(fileUrl));
            System.out.println(result.getETag());
        } catch (AmazonServiceException e) {
            System.err.println(e.getErrorMessage());
            System.exit(1);
        }
    }
}
