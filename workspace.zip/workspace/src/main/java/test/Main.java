package test;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.nuxeo.client.NuxeoClient;
import org.nuxeo.client.objects.Document;

public class Main {

	public static void main(String[] args) {
		
		String url = "https://santander-nuxeo-document-vault-nuxeo-pre.appls.cap2.paas.gsnetcloud.corp/nuxeo";
		//url = "https://santander-nuxeo-document-vault-nuxeo-dev.appls.cap2.paas.gsnetcloud.corp/nuxeo";
		String user = "E1120200";
		String password = "password";
		String id = "08dd37ae-ef1a-40d6-9ac1-49185831a332";
		//id = "0a9d4fcc-c87b-4303-8c47-f8d98013a600";

		NuxeoClient nuxeoClient = null;

		try {
			nuxeoClient = new NuxeoClient.Builder().url(url).authentication(user, password).connect();
		} catch (Exception e) {
			System.out.println("CONNECTION FAILED");
			e.printStackTrace();
			System.exit(1);
		}

		System.out.println("CONNECTED TO NUXEO AS " + nuxeoClient.getCurrentUser().getUserName());

		Document doc = nuxeoClient.repository().fetchDocumentById(id);
		int success = 0;
		for (int i = 1; i <= 100; i++) {
			try {
				IOUtils.toByteArray(doc.fetchBlob().getStream());
			} catch (IOException e) {
				System.out.println("CALL #" + i + " FAILED");
			} finally {
				System.out.println("CALL #" + i + " SUCCESS");
				success++;
			}
		}
		
		System.out.println("SUCCESS RATE " + success + "%");

		nuxeoClient.disconnect();
	}

}
